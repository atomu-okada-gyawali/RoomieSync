import { payShrdExpenses, createShrdExpense, getAllShrdExpenses, getShrdExpenseById, updateShrdExpense, deleteShrdExpense } from '../controller/shrdExpense/shrdExpenseController';
import ShrdExpense from '../model/shrdExpense/ShrdExpense';
import Users from '../model/user/User';

jest.mock('../model/shrdExpense/ShrdExpense');
jest.mock('../model/user/User');

describe('ShrdExpense Controller', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('createShrdExpense should create a new shared expense', async () => {
        const req = {
            body: {
                name: 'Test Expense',
                amount: 100.00,
                agentId: 1,
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        ShrdExpense.create.mockResolvedValue(req.body);

        await createShrdExpense(req, res);

        expect(res.status).toHaveBeenCalledWith(201);
        expect(res.json).toHaveBeenCalledWith(req.body);
    });

    test('getAllShrdExpenses should return all shared expenses', async () => {
        const req = { params: { roomId: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        const mockExpenses = [{ id: 1, name: 'Test Expense' }];
        ShrdExpense.findAll.mockResolvedValue(mockExpenses);

        await getAllShrdExpenses(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith(mockExpenses);
    });

    test('getShrdExpenseById should return a shared expense by ID', async () => {
        const req = { params: { id: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        const mockExpense = { id: 1, name: 'Test Expense' };
        ShrdExpense.findByPk.mockResolvedValue(mockExpense);

        await getShrdExpenseById(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith(mockExpense);
    });

    test('updateShrdExpense should update a shared expense', async () => {
        const req = {
            params: { id: 1 },
            body: {
                name: 'Updated Expense',
                amount: 150.00,
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        const mockExpense = {
            id: 1,
            Name: 'Test Expense',
            save: jest.fn(),
        };
        ShrdExpense.findOne.mockResolvedValue(mockExpense);

        await updateShrdExpense(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith({ message: 'Expense updated successfully' });
    });

    test('deleteShrdExpense should delete a shared expense', async () => {
        const req = { params: { id: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        ShrdExpense.destroy.mockResolvedValue(1); // Expense deleted

        await deleteShrdExpense(req, res);

        expect(res.status).toHaveBeenCalledWith(204);
    });

    test('payShrdExpenses should mark expenses as paid', async () => {
        const req = {
            body: {
                ids: [1, 2],
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        await payShrdExpenses(req, res);

        expect(ShrdExpense.update).toHaveBeenCalledWith(
            { Status: 'paid' },
            { where: { Id: req.body.ids } }
        );
        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith({ message: 'Expenses marked as paid.' });
    });
});
