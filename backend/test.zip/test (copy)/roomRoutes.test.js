import request from 'supertest';
import app from "../index.js";
import { createRoom, joinRoom, deleteRoom } from '../controller/room/roomController';

jest.mock('../controller/room/roomController',()=>({
    create:jest.fn(),
    findAll:jest.fn(),
    findByPk:jest.fn(),
    destroy:jest.fn()
    }));

describe('Room Routes', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('POST /api/rooms should create a new room', async () => {
        const reqBody = {
            name: 'Test Room',
        };

        createRoom.mockImplementation((req, res) => res.status(201).json(reqBody));

        const response = await request(app).post('/api/rooms').send(reqBody);

        expect(response.status).toBe(201);
        expect(response.body).toEqual(reqBody);
    });

    test('POST /api/rooms/join/:rName should allow a user to join a room', async () => {
        const reqParams = { rName: 'Test Room' };
        const mockRoom = { id: 1, name: 'Test Room' };

        joinRoom.mockImplementation((req, res) => res.status(200).json(mockRoom));

        const response = await request(app).post(`/api/rooms/join/${reqParams.rName}`);

        expect(response.status).toBe(200);
        expect(response.body).toEqual(mockRoom);
    });

    test('DELETE /api/rooms/:id should delete a room', async () => {
        const reqParams = { id: 1 };

        deleteRoom.mockImplementation((req, res) => res.status(204).send());

        const response = await request(app).delete(`/api/rooms/${reqParams.id}`);

        expect(response.status).toBe(204);
    });
});
