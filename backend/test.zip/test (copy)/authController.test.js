import { authController } from '../controller/auth/authController'; // Update import
import { User } from '../model/index.js';
import bcrypt from 'bcrypt';

import { generateToken } from '../security/jwt-util.js';

jest.mock('../model/index.js');
jest.mock('bcrypt');
jest.mock('../security/jwt-util.js');

describe('Auth Controller', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('login should authenticate a user and return a token', async () => {
        const req = {
            body: {
                email: 'testuser@example.com',
                password: 'password123',
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        const user = { Email: 'testuser@example.com', Password: 'hashedPassword' };
        User.findOne.mockResolvedValue(user);
        bcrypt.compare.mockResolvedValue(true);
        generateToken.mockReturnValue('token');

        await authController.login(req, res); // Update function call

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.send).toHaveBeenCalledWith({
            data: { access_token: 'token' },
            message: 'Successfully logged in',
        });
    });

    test('login should return 400 if email is missing', async () => {
        const req = { body: { password: 'password123' } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        await authController.login(req, res); // Update function call

        expect(res.status).toHaveBeenCalledWith(400);
        expect(res.send).toHaveBeenCalledWith({ message: 'Email is required' });
    });

    test('login should return 400 if password is missing', async () => {
        const req = { body: { email: 'testuser@example.com' } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        await authController.login(req, res); // Update function call

        expect(res.status).toHaveBeenCalledWith(400);
        expect(res.send).toHaveBeenCalledWith({ message: 'Password is required' });
    });

    test('login should return 404 if user is not found', async () => {
        const req = {
            body: {
                email: 'testuser@example.com',
                password: 'password123',
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        User.findOne.mockResolvedValue(null);

        await authController.login(req, res); // Update function call

        expect(res.status).toHaveBeenCalledWith(404);
        expect(res.send).toHaveBeenCalledWith({ message: 'User not found' });
    });

    test('login should return 401 if password is invalid', async () => {
        const req = {
            body: {
                email: 'testuser@example.com',
                password: 'wrongpassword',
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        const user = { Email: 'testuser@example.com', Password: 'hashedPassword' };
        User.findOne.mockResolvedValue(user);
        bcrypt.compare.mockResolvedValue(false);

        await authController.login(req, res); // Update function call

        expect(res.status).toHaveBeenCalledWith(401);
        expect(res.send).toHaveBeenCalledWith({ message: 'Invalid password' });
    });

    test('init should return the current user', async () => {
        const req = { user: { id: 1, name: 'Test User' } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        await authController.init(req, res); // Update function call

        expect(res.status).toHaveBeenCalledWith(201);
        expect(res.send).toHaveBeenCalledWith({
            data: { id: 1, name: 'Test User' },
            message: 'successfully fetched current user',
        });
    });

    test('init should return 401 if user is not authenticated', async () => {
        const req = { user: null };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        await authController.init(req, res); // Update function call

        expect(res.status).toHaveBeenCalledWith(401);
        expect(res.send).toHaveBeenCalledWith({ message: 'Unauthorized' });
    });
});
