import { sequelize } from '../config/database.js';

beforeEach(async () => {
  // Reset the database state before each test
  await sequelize.sync({ force: true }); // This will drop and recreate the tables
});
