import { createUser, getAllUsers, getUserById, updateUser, leaveRoom, deleteUser } from '../controller/user/userController';
import { User } from '../model/user/User.js';
import bcrypt from 'bcrypt';
import { generateToken } from '../security/jwt-util.js';

jest.mock('../model/user/User.js');
jest.mock('bcrypt');
jest.mock('../security/jwt-util.js');

describe('User Controller', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('createUser should create a new user', async () => {
        const req = {
            body: {
                name: 'Test User',
                contact: '1234567890',
                email: 'testuser@example.com',
                address: '123 Test St',
                password: 'password123',
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        bcrypt.hash.mockResolvedValue('hashedPassword');
        User.create.mockResolvedValue(req.body);

        await createUser(req, res);

        expect(res.status).toHaveBeenCalledWith(201);
        expect(res.send).toHaveBeenCalledWith({
            data: req.body,
            message: 'User created successfully',
        });
    });

    test('getAllUsers should return all users', async () => {
        const req = { params: { roomId: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        User.findAll.mockResolvedValue([{ id: 1, name: 'Test User' }]);

        await getAllUsers(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.send).toHaveBeenCalledWith({
            data: [{ id: 1, name: 'Test User' }],
        });
    });

    test('getUserById should return a user by ID', async () => {
        const req = { params: { id: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        User.findByPk.mockResolvedValue({ id: 1, name: 'Test User' });

        await getUserById(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.send).toHaveBeenCalledWith({
            data: { id: 1, name: 'Test User' },
        });
    });

    test('updateUser should update user details', async () => {
        const req = {
            params: { id: 1 },
            body: {
                name: 'Updated User',
                contact: '0987654321',
                email: 'updateduser@example.com',
                address: '456 Updated St',
                password: 'newpassword123',
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        User.findByPk.mockResolvedValue({
            id: 1,
            save: jest.fn(),
        });
        bcrypt.hash.mockResolvedValue('newHashedPassword');
        generateToken.mockReturnValue('newToken');

        await updateUser(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.send).toHaveBeenCalledWith({
            data: expect.any(Object),
            message: 'User updated successfully',
            token: 'newToken',
        });
    });

    test('leaveRoom should update user room ID', async () => {
        const req = { params: { id: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        User.findByPk.mockResolvedValue({
            id: 1,
            destroy: jest.fn(),
        });
        User.update.mockResolvedValue([1]);
        generateToken.mockReturnValue('newToken');

        await leaveRoom(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.send).toHaveBeenCalledWith({
            message: 'User updated successfully',
            token: 'newToken',
        });
    });

    test('deleteUser should delete a user', async () => {
        const req = { params: { id: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        User.destroy.mockResolvedValue(1);

        await deleteUser(req, res);

        expect(res.status).toHaveBeenCalledWith(204);
    });
});
