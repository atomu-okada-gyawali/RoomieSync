import {
  createChore,
  getAllChores,
  getChoreById,
  updateChore,
  deleteChore,
} from "../controller/chore/choreController";
import Chore from "../model/chore/Chore";
import User from "../model/user/User";
import { Op } from "sequelize";

jest.mock("../model/chore/Chore");
jest.mock("../model/user/User");

describe("Chore Controller", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("createChore should create a new chore with date only", async () => {
    const req = {
      body: {
        name: "Test Chore",
        date: "2023-10-01",
        userId: 1,
        days: null,
      },
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    Chore.create.mockResolvedValue(req.body);

    await createChore(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith(req.body);
  });

  test("createChore should create a new chore with days only", async () => {
    const req = {
      body: {
        name: "Test Chore",
        date: null,
        userId: 1,
        days: ["Monday", "Wednesday"],
      },
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    Chore.create.mockResolvedValue(req.body);

    await createChore(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith(req.body);
  });

  test("getAllChores should return all chores", async () => {
    const req = {
      params: { date: "2023-10-01", roomId: 1, dayOfTheWeek: "Monday" },
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    const mockChores = [{ id: 1, name: "Test Chore" }];
    Chore.findAll.mockResolvedValue(mockChores);

    await getAllChores(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(mockChores);
  });

  test("getChoreById should return a chore by ID", async () => {
    const req = { params: { id: 1 } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    const mockChore = { id: 1, name: "Test Chore" };
    Chore.findByPk.mockResolvedValue(mockChore);

    await getChoreById(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(mockChore);
  });

  test("updateChore should update a chore with date only", async () => {
    const req = {
      params: { id: 1 },
      body: {
        name: "Updated Chore",
        date: "2023-10-02",
        status: "pending",
        days: null,
      },
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
    };

    const mockChore = {
      id: 1,
      Name: "Test Chore",
      save: jest.fn(),
    };
    Chore.findByPk.mockResolvedValue(mockChore);

    await updateChore(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.send).toHaveBeenCalledWith({
      data: mockChore,
      message: "chore updated successfully",
    });
  });

  test("updateChore should update a chore with days only", async () => {
    const req = {
      params: { id: 1 },
      body: {
        name: "Updated Chore",
        date: null,
        status: "pending",
        days: ["Monday", "Wednesday"],
      },
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
    };

    const mockChore = {
      id: 1,
      Name: "Test Chore",
      save: jest.fn(),
    };
    Chore.findByPk.mockResolvedValue(mockChore);

    await updateChore(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.send).toHaveBeenCalledWith({
      data: mockChore,
      message: "chore updated successfully",
    });
  });

  test("deleteChore should delete a chore", async () => {
    const req = { params: { id: 1 } };
    const res = {
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
    };

    Chore.destroy.mockResolvedValue(1); // Room deleted

    await deleteChore(req, res);

    expect(res.status).toHaveBeenCalledWith(204);
  });

  test("deleteChore should return 404 if chore does not exist", async () => {
    const req = { params: { id: 1 } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    Chore.destroy.mockResolvedValue(0); // No chore found

    await deleteChore(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ message: "Chore not found" });
  });
});
