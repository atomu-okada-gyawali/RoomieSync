import request from 'supertest';
import { createChore, getAllChores, getChoreById, updateChore, deleteChore } from '../controller/chore/choreController';
import app from "../index.js";
jest.mock('../controller/chore/choreController');

describe('Chore Routes', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('POST /api/chores should create a new chore', async () => {
        const reqBody = {
            name: 'Test Chore',
            date: '2023-10-01',
            userId: 1,
            days: ['Monday'],
        };

        createChore.mockImplementation((req, res) => res.status(201).json(reqBody));

        const response = await request(app).post('/api/chores').send(reqBody);

        expect(response.status).toBe(201);
        expect(response.body).toEqual(reqBody);
    });

    test('GET /api/chores/all/:date/:roomId/:dayOfTheWeek should return all chores', async () => {
        const reqParams = { date: '2023-10-01', roomId: 1, dayOfTheWeek: 'Monday' };
        const mockChores = [{ id: 1, name: 'Test Chore' }];

        getAllChores.mockImplementation((req, res) => res.status(200).json(mockChores));

        const response = await request(app).get(`/api/chores/all/${reqParams.date}/${reqParams.roomId}/${reqParams.dayOfTheWeek}`);

        expect(response.status).toBe(200);
        expect(response.body).toEqual(mockChores);
    });

    test('GET /api/chores/:id should return a chore by ID', async () => {
        const reqParams = { id: 1 };
        const mockChore = { id: 1, name: 'Test Chore' };

        getChoreById.mockImplementation((req, res) => res.status(200).json(mockChore));

        const response = await request(app).get(`/api/chores/${reqParams.id}`);

        expect(response.status).toBe(200);
        expect(response.body).toEqual(mockChore);
    });

    test('PUT /api/chores/:id should update a chore', async () => {
        const reqParams = { id: 1 };
        const reqBody = {
            name: 'Updated Chore',
            date: '2023-10-02',
            status: 'Completed',
            days: ['Tuesday'],
        };

        updateChore.mockImplementation((req, res) => res.status(200).json({ message: 'Chore updated successfully' }));

        const response = await request(app).put(`/api/chores/${reqParams.id}`).send(reqBody);

        expect(response.status).toBe(200);
        expect(response.body).toEqual({ message: 'Chore updated successfully' });
    });

    test('DELETE /api/chores/:id should delete a chore', async () => {
        const reqParams = { id: 1 };

        deleteChore.mockImplementation((req, res) => res.status(204).send());

        const response = await request(app).delete(`/api/chores/${reqParams.id}`);

        expect(response.status).toBe(204);
    });
});
