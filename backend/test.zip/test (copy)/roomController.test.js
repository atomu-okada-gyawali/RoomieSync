import { createRoom, joinRoom, deleteRoom } from '../controller/room/roomController';
import Room from '../model/room/Room';

jest.mock('../model/room/Room');

describe('Room Controller', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('createRoom should create a new room', async () => {
        const req = {
            body: {
                name: 'Test Room',
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        Room.findOne.mockResolvedValue(null); // No existing room
        Room.create.mockResolvedValue(req.body);

        await createRoom(req, res);

        expect(res.status).toHaveBeenCalledWith(201);
        expect(res.json).toHaveBeenCalledWith(req.body);
    });

    test('createRoom should return 409 if room already exists', async () => {
        const req = {
            body: {
                name: 'Test Room',
            },
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        Room.findOne.mockResolvedValue({}); // Existing room

        await createRoom(req, res);

        expect(res.status).toHaveBeenCalledWith(409);
        expect(res.json).toHaveBeenCalledWith({ message: 'Room already exists' });
    });

    test('joinRoom should return a room if it exists', async () => {
        const req = { params: { rName: 'Test Room' } };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        const mockRoom = { id: 1, name: 'Test Room' };
        Room.findOne.mockResolvedValue(mockRoom);

        await joinRoom(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith(mockRoom);
    });

    test('joinRoom should return 404 if room does not exist', async () => {
        const req = { params: { rName: 'Nonexistent Room' } };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        Room.findOne.mockResolvedValue(null); // No room found

        await joinRoom(req, res);

        expect(res.status).toHaveBeenCalledWith(404);
        expect(res.json).toHaveBeenCalledWith({ message: 'Room not found' });
    });

    test('deleteRoom should delete a room', async () => {
        const req = { params: { id: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };

        Room.destroy.mockResolvedValue(1); // Room deleted

        await deleteRoom(req, res);

        expect(res.status).toHaveBeenCalledWith(204);
    });

    test('deleteRoom should return 404 if room does not exist', async () => {
        const req = { params: { id: 1 } };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };

        Room.destroy.mockResolvedValue(0); // No room found

        await deleteRoom(req, res);

        expect(res.status).toHaveBeenCalledWith(404);
        expect(res.json).toHaveBeenCalledWith({ message: 'Room not found' });
    });
});
