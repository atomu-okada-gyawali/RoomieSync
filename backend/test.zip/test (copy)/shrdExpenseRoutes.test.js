import { request } from "supertest";
import app from "../index.js";
const {
  createShrdExpense,
  payShrdExpenses,
  getAllShrdExpenses,
  getShrdExpenseById,
  updateShrdExpense,
  deleteShrdExpense,
} = require("../controller/shrdExpense/shrdExpenseController");

jest.mock("../controller/shrdExpense/shrdExpenseController");

describe("ShrdExpense Routes", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("POST /api/shrdExpenses should create a new shared expense", async () => {
    const reqBody = {
      name: "Test Expense",
      amount: 100.0,
      agentId: 1,
    };

    createShrdExpense.mockImplementation((req, res) =>
      res.status(201).json(reqBody)
    );

    const response = await request(app).post("/api/shrdExpenses").send(reqBody);

    expect(response.status).toBe(201);
    expect(response.body).toEqual(reqBody);
  });

  test("PUT /api/shrdExpenses/pay should mark expenses as paid", async () => {
    const reqBody = {
      ids: [1, 2],
    };

    payShrdExpenses.mockImplementation((req, res) =>
      res.status(200).json({ message: "Expenses marked as paid." })
    );

    const response = await request(app)
      .put("/api/shrdExpenses/pay")
      .send(reqBody);

    expect(response.status).toBe(200);
    expect(response.body).toEqual({ message: "Expenses marked as paid." });
  });

  test("GET /api/shrdExpenses/all/:roomId should return all shared expenses", async () => {
    const reqParams = { roomId: 1 };
    const mockExpenses = [{ id: 1, name: "Test Expense" }];

    getAllShrdExpenses.mockImplementation((req, res) =>
      res.status(200).json(mockExpenses)
    );

    const response = await request(app).get(
      `/api/shrdExpenses/all/${reqParams.roomId}`
    );

    expect(response.status).toBe(200);
    expect(response.body).toEqual(mockExpenses);
  });

  test("GET /api/shrdExpenses/:id should return a shared expense by ID", async () => {
    const reqParams = { id: 1 };
    const mockExpense = { id: 1, name: "Test Expense" };

    getShrdExpenseById.mockImplementation((req, res) =>
      res.status(200).json(mockExpense)
    );

    const response = await request(app).get(
      `/api/shrdExpenses/${reqParams.id}`
    );

    expect(response.status).toBe(200);
    expect(response.body).toEqual(mockExpense);
  });

  test("PUT /api/shrdExpenses/:id should update a shared expense", async () => {
    const reqParams = { id: 1 };
    const reqBody = {
      name: "Updated Expense",
      amount: 150.0,
    };

    updateShrdExpense.mockImplementation((req, res) =>
      res.status(200).json({ message: "Expense updated successfully" })
    );

    const response = await request(app)
      .put(`/api/shrdExpenses/${reqParams.id}`)
      .send(reqBody);

    expect(response.status).toBe(200);
    expect(response.body).toEqual({ message: "Expense updated successfully" });
  });

  test("DELETE /api/shrdExpenses/:id should delete a shared expense", async () => {
    const reqParams = { id: 1 };

    deleteShrdExpense.mockImplementation((req, res) => res.status(204).send());

    const response = await request(app).delete(
      `/api/shrdExpenses/${reqParams.id}`
    );

    expect(response.status).toBe(204);
  });
});
