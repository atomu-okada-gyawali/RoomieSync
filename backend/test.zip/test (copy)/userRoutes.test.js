import request from "supertest";
import app from "../index.js";

describe("User Routes", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("POST /api/users should create a new user", async () => {
    const reqBody = {
      name: "Test User",
      contact: "1234567890",
      email: "testuser@example.com",
      address: "123 Test St",
      password: "password123",
    };

    const response = await request(app).post("/api/users").send(reqBody);

    expect(response.status).toBe(201);
    expect(response.body).toEqual(reqBody);
  });

  test("GET /api/users/all/:roomId should return all users", async () => {
    const reqParams = { roomId: 1 };
    const mockUsers = [{ id: 1, name: "Test User" }];

    const response = await request(app).get(
      `/api/users/all/${reqParams.roomId}`
    );

    expect(response.status).toBe(200);
    expect(response.body).toEqual(mockUsers);
  });

  test("GET /api/users/:id should return a user by ID", async () => {
    const reqParams = { id: 1 };
    const mockUser = { id: 1, name: "Test User" };

    const response = await request(app).get(`/api/users/${reqParams.id}`);

    expect(response.status).toBe(200);
    expect(response.body).toEqual(mockUser);
  });

  test("PUT /api/users/leaveRoom/:id should allow a user to leave a room", async () => {
    const reqParams = { id: 1 };

    const response = await request(app).put(
      `/api/users/leaveRoom/${reqParams.id}`
    );

    expect(response.status).toBe(200);
    expect(response.body).toEqual({ message: "User updated successfully" });
  });

  test("PUT /api/users/:id should update a user", async () => {
    const reqParams = { id: 1 };
    const reqBody = {
      name: "Updated User",
      contact: "0987654321",
      email: "updateduser@example.com",
      address: "456 Updated St",
      password: "newpassword123",
    };

    const response = await request(app)
      .put(`/api/users/${reqParams.id}`)
      .send(reqBody);

    expect(response.status).toBe(200);
    expect(response.body).toEqual({ message: "User updated successfully" });
  });

  test("DELETE /api/users/:id should delete a user", async () => {
    const reqParams = { id: 1 };

    const response = await request(app).delete(`/api/users/${reqParams.id}`);

    expect(response.status).toBe(204);
  });
});
